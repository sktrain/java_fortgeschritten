package Aufgaben_2_7;

import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Aufgabe_2 {

	public static void main(String[] args) {
		
		final Runnable runner = null;  // ... TODO ...
				
		new Thread(runner).start();
	}

}
