PosNegCounter: Berechnung der Anzahl der positiven, negativen und 0-Werte in einem gegebenen Array 
               mittels eines Stream-Durchlaufs. 
               (Hinweis: geht mit vorhandenen Collectoren aber auch mit selbstgeschriebenem Collector) 


Reduce_Sum_Fak: Berechnung des Produkts der positiven Ganzzahlen von 1 bis 100 (Fakult�t)
                und der Summe dieser Zahlen in einem Stream-Durchlauf mittels eigenem Reducer.