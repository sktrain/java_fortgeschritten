# Umstellung des Standard-Samples auf meine H2

Meine H2 hat keinen Key-Generator, deshalb muss das schon mal weg.
