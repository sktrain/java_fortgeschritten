package headfirst.observer.weather.sol1;

public interface DisplayElement {
	public void display();
}
