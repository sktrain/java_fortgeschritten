package headfirst.observer.weather.sol1;

public interface Observer {
	public void update(float temp, float humidity, float pressure);
}
