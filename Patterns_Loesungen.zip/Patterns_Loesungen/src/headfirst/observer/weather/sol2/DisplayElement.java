package headfirst.observer.weather.sol2;

public interface DisplayElement {
	public void display();
}
