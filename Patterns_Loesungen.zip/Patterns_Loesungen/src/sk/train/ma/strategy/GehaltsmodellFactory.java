package sk.train.ma.strategy;

import java.math.BigDecimal;

public class GehaltsmodellFactory {

	public static void main(String[] args) {

         Gehaltsmodell g = Gehaltsmodell.getGehaltsmodell("A");
         System.out.println(g);
         
         g = Gehaltsmodell.getGehaltsmodell("F");
         System.out.println(g);

	}
	
	/*
	 * public static Gehaltsmodell getGehaltsmodell(String type) { if
	 * (type.equals("A")) return new ArbeiterModell(new BigDecimal(17), new
	 * BigDecimal(120)); else return new FixGehaltModell(new BigDecimal(5000)); }
	 */

}
