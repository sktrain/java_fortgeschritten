package sk.train.ma.strategy;

public enum Geschlecht { W, M, D

}
