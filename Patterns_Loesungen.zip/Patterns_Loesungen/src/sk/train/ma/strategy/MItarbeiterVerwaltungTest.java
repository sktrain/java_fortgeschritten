package sk.train.ma.strategy;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MItarbeiterVerwaltungTest {

	public static void main(String[] args) {

		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();

		System.out.println(mv.getGehaltssumme());
		System.out.println("\n***********************************\n");

		System.out.println(mv);

		System.out.println("\n***********************************\n");

		List<Mitarbeiter> mlist = mv.getMlist();
		for (Mitarbeiter m : mlist)
			System.out.println(m);

		System.out.println("\n***********************************\n");

		// Jetzt nach Geh�ltern sortiert
		System.out.println("Hier nach Gehalt sortiert");
		Collections.sort(mlist);
		for (Mitarbeiter m : mlist)
			System.out.println(m);

		System.out.println("\n***********************************\n");

		// jetzt nach Nachnamen sortiert
		Collections.sort(mlist, new NachnamenComparator());
		// Alternativ als Lambda geschrieben
		// Arrays.sort(mv.getMarray(), (arg0,arg1) ->
		// arg0.getNachname().compareTo(arg1.getNachname()));
		for (Mitarbeiter m : mlist)
			System.out.println(m);

		System.out.println("\n***********************************\n");

		// jetzt mal nur per Lambda nach den Geburtsdaten und Ausgabe mit
		// foreach-Lambda-Version
		Comparator<Mitarbeiter> cgebdatum = (Mitarbeiter m1, Mitarbeiter m2) -> {
			return m1.getGebdatum().compareTo(m2.getGebdatum());
		};
		Collections.sort(mlist, cgebdatum);
		mlist.forEach(System.out::println);

		System.out.println("\n***********************************\n");

		// und jetzt mal zuerst nach den Geburtsdaten und dann nachsortiert anhand der
		// Geh�lter
		Comparator<Mitarbeiter> cgehalt = (Mitarbeiter m1, Mitarbeiter m2) -> {
			return m1.getGmodel().getGehalt().compareTo(m2.getGmodel().getGehalt());
		};
		Collections.sort(mlist, cgebdatum.thenComparing(cgehalt));
		mlist.forEach(System.out::println);

		System.out.println("\n***********************************\n");

		// und jetzt mal zur�ck zur nat�rlichen Ordnung
		Collections.sort(mlist, Comparator.naturalOrder());
		mlist.forEach(System.out::println);

	}

}
