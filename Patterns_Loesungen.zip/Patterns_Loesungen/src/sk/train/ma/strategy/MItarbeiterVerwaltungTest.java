package sk.train.ma.strategy;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MItarbeiterVerwaltungTest {

	public static void main(String[] args) {

		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();
		
		mv.getMset().forEach(System.out::println);

		/*
		 * System.out.println(mv.getGehaltssumme());
		 * System.out.println("\n***********************************\n");
		 * 
		 * for (Mitarbeiter m : mv.getMarray()) System.out.println(m);
		 * 
		 * System.out.println("\n***********************************\n"); for
		 * (Mitarbeiter m : mv.getMlist()) System.out.println(m);
		 * 
		 * //Jetzt nach Geh�ltern sortiert
		 * 
		 * System.out.println("\n***********************************\n");
		 * System.out.println("Hier nach Gehalt sortiert");
		 * 
		 * Arrays.sort(mv.getMarray());
		 * 
		 * Collections.sort(mv.getMlist());
		 * 
		 * for (Mitarbeiter m : mv.getMarray()) System.out.println(m);
		 * 
		 * System.out.println("\n***********************************\n");
		 * 
		 * for (Mitarbeiter m : mv.getMlist()) System.out.println(m);
		 * 
		 * // jetzt nach Nachnamen sortiert
		 * System.out.println("\n***********************************\n");
		 * 
		 * Arrays.sort(mv.getMarray(), new NachnamenComparator());
		 * 
		 * //Alternativ als Lambda geschrieben //Arrays.sort(mv.getMarray(), (arg0,
		 * arg1) -> arg0.getNachname().compareTo(arg1.getNachname()));
		 * 
		 * for (Mitarbeiter m : mv.getMarray()) System.out.println(m);
		 * 
		 * 
		 * // jetzt mal nur per Lambda nach den Geburtsdaten und Ausgabe mit
		 * foreach-Lambda-Version
		 * System.out.println("\n***********************************\n");
		 * 
		 * Comparator<Mitarbeiter> cgebdatum = (Mitarbeiter m1, Mitarbeiter m2) ->
		 * {return m1.getGebdatum().compareTo(m2.getGebdatum());};
		 * Arrays.sort(mv.getMarray(), cgebdatum);
		 * 
		 * Arrays.asList(mv.getMarray()).forEach(m -> System.out.println(m));
		 * 
		 * // und jetzt mal zuerst nach den Geburtsdaten und dann nachsortiert anhand
		 * der Geh�lter System.out.println("\n***********************************\n");
		 * 
		 * Comparator<Mitarbeiter> cgehalt = (Mitarbeiter m1, Mitarbeiter m2) -> {
		 * return m1.getGehalt().compareTo(m2.getGehalt()); };
		 * Arrays.sort(mv.getMarray(), cgebdatum.thenComparing(cgehalt));
		 * 
		 * Arrays.asList(mv.getMarray()).forEach(m -> System.out.println(m));
		 * 
		 * // und jetzt mal zur�ck zur nat�rlichen Ordnung
		 * System.out.println("\n***********************************\n");
		 * 
		 * Arrays.sort(mv.getMarray(), Comparator.naturalOrder());
		 * 
		 * Arrays.asList(mv.getMarray()).forEach(m -> System.out.println(m));
		 */
		
		Writer out = null;
		
		try {
		    out = Files.newBufferedWriter(Paths.get("mitarbeiter.txt"), StandardCharsets.ISO_8859_1);
			for (Mitarbeiter m : mv.getMarray()) {
				out.write(m.toString());
			    out.write(System.lineSeparator());
			}
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

		 
	}

}
