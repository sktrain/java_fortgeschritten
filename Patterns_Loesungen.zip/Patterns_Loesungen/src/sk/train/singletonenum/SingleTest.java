package sk.train.singletonenum;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;

public class SingleTest {
	
	public static void main(String[] args) {
		System.out.println(SingleLocalDate.S.getL());
		SingleLocalDate.S.setL(10);
		System.out.println(SingleLocalDate.S.getL());
		System.out.println(SingleLocalDate.S.l2);
		
		SingleLocalDate single1 = SingleLocalDate.S;
		SingleLocalDate single2 = single1;
		
		//but with serialization
		try (
		 ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(bos)) {
			oos.writeObject(single1);			
			ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(bis);
			single2 = (SingleLocalDate) ois.readObject();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		System.out.println(single1 == single2);  //true, serialization returns original
		
		//but with reflection
		single2 = single1;
		Class<? extends SingleLocalDate> clazz = single1.getClass();
		Constructor<? extends SingleLocalDate> con = null;;
		try {
				con = clazz.getDeclaredConstructor(LocalDate.class);
				con.setAccessible(true);
			} catch (NoSuchMethodException | SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		try {
				single2 = (SingleLocalDate) con.newInstance(LocalDate.of(1900, 1, 1));
			} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		System.out.println(single1 == single2);  //reflection results in exception
	}


}
