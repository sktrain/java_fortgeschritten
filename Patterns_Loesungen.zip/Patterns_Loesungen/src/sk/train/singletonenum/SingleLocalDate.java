package sk.train.singletonenum;

import java.time.LocalDate;

public enum SingleLocalDate {
	
	S(LocalDate.of(2000, 1, 1));
	
	private final LocalDate l;
	public LocalDate l2 ;
	
	private SingleLocalDate(LocalDate l) {
		this.l = l;
		//l2 = l;
	}
	public LocalDate getL() {
		return l;
	}
	public void setL(int y) {
		l2 = this.l.minusYears(y);
	}
	
	public static void main(String[] args) {
		System.out.println(SingleLocalDate.S.getL());
		SingleLocalDate.S.setL(10);
		System.out.println(SingleLocalDate.S.getL());
		System.out.println(S.l2);
	}

}
