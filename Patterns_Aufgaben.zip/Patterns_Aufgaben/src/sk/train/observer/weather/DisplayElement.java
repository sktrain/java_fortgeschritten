package sk.train.observer.weather;

public interface DisplayElement {
	public void display();
}
