package sk.train.ma.abs;

public enum Geschlecht { W, M, D

}
