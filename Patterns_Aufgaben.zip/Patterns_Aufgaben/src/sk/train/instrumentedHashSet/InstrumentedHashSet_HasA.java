package sk.train.instrumentedHashSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class InstrumentedHashSet_HasA<E>  
{
    // The number of attempted element insertions
    private int addCount = 0;
    
    private HashSet<E> myhash;

    public InstrumentedHashSet_HasA() {
           myhash = new HashSet<E>();}

    
    
    public boolean add(E e) {
        addCount++;
        return myhash.add(e);
    }

    public boolean addAll(Collection<? extends E> c) {
        addCount += c.size();
        return myhash.addAll(c);
    }

    public int getAddCount() {
        return addCount;
    }

    public static void main(String[] args) {
        InstrumentedHashSet_HasA<String> s =
            new InstrumentedHashSet_HasA<String>();
        s.addAll(Arrays.asList("Snap", "Crackle", "Pop"));    
        System.out.println(s.getAddCount());
    }
}
