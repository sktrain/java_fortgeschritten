Basisversion der Mitarbeiterklasse mit �berschriebenen Standardmethoden 
(toString, equals, hashcode)