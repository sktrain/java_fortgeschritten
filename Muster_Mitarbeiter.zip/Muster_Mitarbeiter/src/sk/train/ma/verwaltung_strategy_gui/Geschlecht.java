package sk.train.ma.verwaltung_strategy_gui;

public enum Geschlecht { W, M, D

}
