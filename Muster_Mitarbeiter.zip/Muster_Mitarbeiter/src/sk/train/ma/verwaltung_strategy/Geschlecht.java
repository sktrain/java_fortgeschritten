package sk.train.ma.verwaltung_strategy;

public enum Geschlecht { W, M, D

}
