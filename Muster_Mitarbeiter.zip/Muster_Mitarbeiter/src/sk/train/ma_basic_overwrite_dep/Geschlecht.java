package sk.train.ma_basic_overwrite_dep;

public enum Geschlecht { W, M, D

}
