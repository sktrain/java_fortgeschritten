package sk.train.ma_verwaltung_abstract_gui;

public enum Geschlecht { W, M, D

}
