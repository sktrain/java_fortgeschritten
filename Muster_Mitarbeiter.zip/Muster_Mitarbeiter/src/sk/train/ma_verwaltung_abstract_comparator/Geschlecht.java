package sk.train.ma_verwaltung_abstract_comparator;

public enum Geschlecht { W, M, D

}
