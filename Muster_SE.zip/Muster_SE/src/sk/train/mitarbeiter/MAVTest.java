package sk.train.mitarbeiter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;

public class MAVTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		DBConnect dbc = new DBConnect();
		Connection c = dbc.createConnection();
		MAV mymav = new MAV(c);
		
		System.out.println(mymav);
		
		Arrays.sort(mymav.getMarray());
		
		System.out.println("***************************************************");
		
		System.out.println(mymav);
		
		Arrays.sort(mymav.getMarray(), 
				( arg0,arg1)	->  ((Mitarbeiter)arg0).getName().compareTo(((Mitarbeiter)arg1).getName()));
		
		System.out.println("***************************************************");
		
		System.out.println(mymav);
		
		dbc.closeConnection();
		
		System.out.println(Thread.currentThread());

	}

}
