package sk.train.mitarbeiter;

import org.omg.CORBA.portable.ApplicationException;

public class Arbeiter extends Mitarbeiter{
	
	private int stdlohn;
	private int stdzahl;
	
	public Arbeiter(int persnr, String name, int stdlohn, int stdzahl) throws ApplicationException {
		super(persnr, name, stdlohn*stdzahl);
		this.stdlohn = stdlohn;
		this.stdzahl = stdzahl;
	}

	public int getStdlohn() {
		return stdlohn;
	}

	public void setStdlohn(int stdlohn) {
		super.setGehalt(stdlohn*stdzahl);
		this.stdlohn = stdlohn;
	}

	public int getStdzahl() {
		return stdzahl;
	}

	public void setStdzahl(int stdzahl) {
		super.setGehalt(stdlohn*stdzahl);
		this.stdzahl = stdzahl;
	}
	
	

}
