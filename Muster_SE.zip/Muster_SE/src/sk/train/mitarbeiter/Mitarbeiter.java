package sk.train.mitarbeiter;

import org.omg.CORBA.portable.ApplicationException;

public class Mitarbeiter implements Comparable<Mitarbeiter> {
	
	private int persnr;
	private String name;
	private int gehalt;
	
	public Mitarbeiter(int persnr, String name, int gehalt) throws ApplicationException {
		super();
		this.persnr = persnr;
		this.name = name;
		if (gehalt > 0){
			this.gehalt = gehalt;
		} else{
			throw new ApplicationException("kein negatives Gehalt erlaubt", null);
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getGehalt() {
		return gehalt;
	}

	public void setGehalt(int gehalt) {
		this.gehalt = gehalt;
	}

	public int getPersnr() {
		return persnr;
	}

	@Override
	public String toString() {
		return "Mitarbeiter [persnr=" + persnr + ", name=" + name + ", gehalt=" + gehalt + "]";
	}
	
	public boolean equals(Mitarbeiter other){
		if (this.gehalt != other.gehalt){
			return false;
		}
		if (!this.name.equals(other.name)){
			return false;
		}
		if (this.persnr != other.persnr){
			return false;
		}
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + gehalt;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + persnr;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mitarbeiter other = (Mitarbeiter) obj;
		if (gehalt != other.gehalt)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (persnr != other.persnr)
			return false;
		return true;
	}

	@Override
	public int compareTo(Mitarbeiter other) {
		//Mitarbeiter other = (Mitarbeiter)arg0;
		if (this.gehalt < other.gehalt){
			return -1;}
		if (this.gehalt > other.gehalt){
			return 1;
		}
		return 0;
	}
	
	
	

}
