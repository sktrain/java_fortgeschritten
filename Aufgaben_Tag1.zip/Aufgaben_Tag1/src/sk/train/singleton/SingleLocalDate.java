package sk.train.singleton;

import java.time.LocalDate;

public class SingleLocalDate {
	
	private LocalDate date;

	//todo: es soll nur eine Instanz von dieser Klasse geben
	//z.B. mit Datum 1.1.2000
	
	
}
