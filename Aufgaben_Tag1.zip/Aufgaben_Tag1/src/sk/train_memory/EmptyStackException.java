package sk.train_memory;

public class EmptyStackException extends IllegalStateException {

	private static final long serialVersionUID = 1L;
}
