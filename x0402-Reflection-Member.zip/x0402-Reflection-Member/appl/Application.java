package appl;

import java.lang.reflect.*;

public class Application {
	public static void main(String[] args) {
		test1();
		test2();
		test3();
	}

	private static void test1() {
		System.out.println();
		try {
			Class<?> cls = Class.forName("appl.C");
			Field[] fields = cls.getFields();
			for (Field field : fields) {
				Class<?> type = field.getType();
				System.out.print(type.getSimpleName());
				System.out.println(" " + field.getName());
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	private static void test2() {
		System.out.println();
		try {
			Class<?> cls = Class.forName("appl.C");
			Method[] methods = cls.getMethods();
			for (Method method : methods) {
				Class<?> returnType = method.getReturnType();
				System.out.print(returnType.getSimpleName() + " ");
				System.out.print(method.getName() + "(");
				Class<?>[] parameterTypes = method.getParameterTypes();
				for (int i = 0; i < parameterTypes.length; i++) {
					if (i > 0)
						System.out.print(", ");
					Class<?> parameterType = parameterTypes[i];
					System.out.print(parameterType.getSimpleName());
				}
				System.out.println(")");
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	private static void test3() {
		System.out.println();
		try {
			Class<?> cls = Class.forName("appl.C");
			Constructor<?>[] constructors = cls.getConstructors();
			for (Constructor<?> constructor : constructors) {
				System.out.print(constructor.getName() + "(");
				Class<?>[] parameterTypes = constructor.getParameterTypes();
				for (int i = 0; i < parameterTypes.length; i++) {
					if (i > 0)
						System.out.print(", ");
					Class<?> parameterType = parameterTypes[i];
					System.out.print(parameterType.getSimpleName());
				}
				System.out.println(")");
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
}