package sk.train.observer.weather.sol3;

import java.beans.PropertyChangeListener;

public interface Observable {

	void addPropertyChangeListener(PropertyChangeListener l);

	void removePropertyChangeListener(PropertyChangeListener l);

}