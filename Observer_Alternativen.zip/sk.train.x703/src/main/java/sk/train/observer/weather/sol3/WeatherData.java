package sk.train.observer.weather.sol3;
	
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
	
public class WeatherData implements Observable {
	
	private float[] measures;
	
	private PropertyChangeSupport changes; 
	
	public WeatherData() {
		changes = new PropertyChangeSupport( this );
		measures = new float[3];
	}
	
	@Override
	public void addPropertyChangeListener( PropertyChangeListener l ) {
	    changes.addPropertyChangeListener( l );
	  }

	@Override
	public void removePropertyChangeListener( PropertyChangeListener l ) {
	    changes.removePropertyChangeListener( l );
	  }
	
	public void setMeasurements(float temperature, float humidity, float pressure) {
		float[] newMeasures = {temperature, humidity, pressure};
		changes.firePropertyChange( "data", measures, newMeasures );
		measures = newMeasures;
	}
	
//	public float getTemperature() {
//		return temperature;
//	}
//	
//	public float getHumidity() {
//		return humidity;
//	}
//	
//	public float getPressure() {
//		return pressure;
//	}
}
