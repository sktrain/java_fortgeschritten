package sk.train.observer.weather.sol3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class ForecastDisplay implements PropertyChangeListener, DisplayElement {
	
	// an sich braucht man hier nicht mehr alt und neu, da das Event alt und neu enth�lt
	private float currentPressure = 29.92f;  
	private float lastPressure;
	private Observable weatherdata;

	public ForecastDisplay(Observable observable) {
		weatherdata = observable;
		weatherdata.addPropertyChangeListener(this);
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		float[] measures = (float[]) evt.getNewValue();
		lastPressure = currentPressure;
		currentPressure = measures[2]; 
		display();		
	}


	public void display() {
		System.out.print("Forecast: ");
		if (currentPressure > lastPressure) {
			System.out.println("Improving weather on the way!");
		} else if (currentPressure == lastPressure) {
			System.out.println("More of the same");
		} else if (currentPressure < lastPressure) {
			System.out.println("Watch out for cooler, rainy weather");
		}
	}

}
