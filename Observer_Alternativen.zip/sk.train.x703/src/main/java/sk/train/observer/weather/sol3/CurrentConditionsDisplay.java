package sk.train.observer.weather.sol3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class CurrentConditionsDisplay implements PropertyChangeListener, DisplayElement {

	private float temperature;
	private float humidity;
	private Observable weatherdata;

	public CurrentConditionsDisplay(Observable weatherdata) {
		super();
		this.weatherdata = weatherdata;
		weatherdata.addPropertyChangeListener(this);
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		float[] measures = (float[]) evt.getNewValue();
		this.temperature = measures[0];
		this.humidity = measures[1];
		display();
	}

	public void display() {
		System.out.println("Current conditions: " + temperature + "F degrees and " + humidity + "% humidity");
	}

	
}
