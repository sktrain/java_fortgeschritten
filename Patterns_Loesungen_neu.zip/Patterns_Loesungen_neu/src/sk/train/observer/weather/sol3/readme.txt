Umsetzung des Observer/Observable-Pattern:
 
Nutzung des PropertyChangeListener-Ansatzes aus dem Package java.beans.
Da dieser Ansatz auf dem feuern von PropertyChangeEvents beruht, die sowohl 
den vorherigen Wert als auch den aktualisierten Wert �bermitteln, werden die
�nderungen jetzt direkt den Observern mitgeteilt, statt dass diese selbst die 
�nderungen erfragen.
Zus�tzlich ist ein Kopieren der Werte erforderlich (Referenzensemantik hilft hier nicht),
da die Events nur gefeuert werden, wenn sich alte und neue Werte unterscheiden.