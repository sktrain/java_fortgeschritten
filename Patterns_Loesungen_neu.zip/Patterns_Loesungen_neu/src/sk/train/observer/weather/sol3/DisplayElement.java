package sk.train.observer.weather.sol3;

public interface DisplayElement {
	public void display();
}
