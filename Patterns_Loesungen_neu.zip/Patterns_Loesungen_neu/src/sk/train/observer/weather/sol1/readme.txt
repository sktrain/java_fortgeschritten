Umsetzung des Observer/Observable-Pattern

Eigene Verwaltung der Observer auf der Observable-Seite.