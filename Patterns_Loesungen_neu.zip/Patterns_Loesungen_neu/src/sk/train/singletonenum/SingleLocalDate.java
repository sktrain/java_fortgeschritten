package sk.train.singletonenum;

import java.time.LocalDate;

public enum SingleLocalDate {
	
	S(LocalDate.of(2000, 1, 1));
	
	private LocalDate l;
	
	private SingleLocalDate(LocalDate l) {
		this.l = l;
	}
	
	public LocalDate getL() {
		return l;
	}
	
	public void setL(LocalDate l) {
		this.l = l;
	}


//	private LocalDate secondDate ;
//	
//	
//	
//	
//	public void setSecondDate(int y) {
//		secondDate = this.l.minusYears(y);
//	}
	
}
