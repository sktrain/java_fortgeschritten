package sk.train.ma.strategyfactory;

public enum Geschlecht { W, M, D

}
