package sk.train.ma.strategy;

import java.math.BigDecimal;

public interface Gehaltsmodell {
	
	public abstract BigDecimal getGehalt();

}
