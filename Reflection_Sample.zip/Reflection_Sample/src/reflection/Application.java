package reflection;

import java.lang.reflect.*;


//sicherlich ausbaubar !!

public class Application {
	public static void main(String[] args) {
		
		String fullname = "reflection.C";
		
		//Analysieren
		getFields(fullname);
		getMethods(fullname);
		getConstructors(fullname);
		
		getSecretFields(fullname);
		getSecretMethods(fullname);
		getSecretConstructors(fullname);
		
		//Objekt erzeugen
		createDefaultConstructor(fullname);
		createExplicitConstructor(fullname);
		
		
	}

	private static void getFields(String name) {
		System.out.println();
		try {
			Class<?> cls = Class.forName(name);
			Field[] fields = cls.getFields();
			for (Field field : fields) {
				Class<?> type = field.getType();
				System.out.print(type.getSimpleName());
				System.out.println(" " + field.getName());
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	private static void getMethods(String name) {
		System.out.println();
		try {
			Class<?> cls = Class.forName(name);
			Method[] methods = cls.getMethods();
			for (Method method : methods) {
				Class<?> returnType = method.getReturnType();
				System.out.print(returnType.getSimpleName() + " ");
				System.out.print(method.getName() + "(");
				Class<?>[] parameterTypes = method.getParameterTypes();
				for (int i = 0; i < parameterTypes.length; i++) {
					if (i > 0)
						System.out.print(", ");
					Class<?> parameterType = parameterTypes[i];
					System.out.print(parameterType.getSimpleName());
				}
				System.out.println(")");
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	private static void getConstructors(String name) {
		System.out.println();
		try {
			Class<?> cls = Class.forName(name);
			Constructor<?>[] constructors = cls.getConstructors();
			for (Constructor<?> constructor : constructors) {
				System.out.print(constructor.getName() + "(");
				Class<?>[] parameterTypes = constructor.getParameterTypes();
				for (int i = 0; i < parameterTypes.length; i++) {
					if (i > 0)
						System.out.print(", ");
					Class<?> parameterType = parameterTypes[i];
					System.out.print(parameterType.getSimpleName());
				}
				System.out.println(")");
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
	
	
	//optional:
	private static void getSecretFields(String name) {
		System.out.println();
		System.out.println("Nicht sichtbare Attribute\n");
		try {
			Class<?> cls = Class.forName(name);
			Field[] fields = cls.getDeclaredFields();
			for (Field field : fields) {
				int mod = field.getModifiers();
				if (! Modifier.isPublic(mod)) {
				Class<?> type = field.getType();
				System.out.print(" " + type.getSimpleName());
				System.out.println(" " + field.getName());
				}
			}
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
	
	private static void getSecretMethods(String name) {
		System.out.println();
		System.out.println("Nicht sichtbare Methoden\n");
		try {
			Class<?> cls = Class.forName(name);
			Method[] methods = cls.getDeclaredMethods();
			for (Method method : methods) {
				int mod = method.getModifiers();
				if (!Modifier.isPublic(mod)) {
					Class<?> returnType = method.getReturnType();
					System.out.print(returnType.getSimpleName() + " ");
					System.out.print(method.getName() + "(");
					Class<?>[] parameterTypes = method.getParameterTypes();
					for (int i = 0; i < parameterTypes.length; i++) {
						if (i > 0)
							System.out.print(", ");
						Class<?> parameterType = parameterTypes[i];
						System.out.print(parameterType.getSimpleName());
					}
					System.out.println(")");
				}
			}
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
	
	private static void getSecretConstructors(String name) {
		System.out.println();
		System.out.println("Nicht sichtbare Konstruktoren\n");
		try {
			Class<?> cls = Class.forName(name);
			Constructor<?>[] constructors = cls.getDeclaredConstructors();
			for (Constructor<?> constructor : constructors) {
				int mod = constructor.getModifiers();
				if (!Modifier.isPublic(mod)) {
					System.out.print(constructor.getName() + "(");
					Class<?>[] parameterTypes = constructor.getParameterTypes();
					for (int i = 0; i < parameterTypes.length; i++) {
						if (i > 0)
							System.out.print(", ");
						Class<?> parameterType = parameterTypes[i];
						System.out.print(parameterType.getSimpleName());
					}
					System.out.println(")");
				}
			}
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
	
	private static void createDefaultConstructor(String name) {
		System.out.println();
		try {
			Class<?> cls = Class.forName(name);
			Constructor<?> constructor = cls.getConstructor();
			Object obj = constructor.newInstance();
			System.out.println(obj);
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
		catch (InstantiationException e) {
			System.out.println(e);
		}
		catch (IllegalAccessException e) {
			System.out.println(e);
		}
		catch (NoSuchMethodException e) {
			System.out.println(e);
		}
		catch (InvocationTargetException e) {
			System.out.println(e);
		}
	}

	private static void createExplicitConstructor(String name) {
		System.out.println();
		try {
			Class<?> cls = Class.forName(name);
			Constructor<?> constructor = cls.getConstructor(int.class, String.class);
			Object obj = constructor.newInstance(1000, "Hello World");
			System.out.println(obj);
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
		catch (InstantiationException e) {
			System.out.println(e);
		}
		catch (IllegalAccessException e) {
			System.out.println(e);
		}
		catch (NoSuchMethodException e) {
			System.out.println(e);
		}
		catch (InvocationTargetException e) {
			System.out.println(e);
		}
	}
}