Umsetzung des Observer/Observable-Pattern

WeatherStation soll das Observable sein, welches die Wetterdaten bereit stellt. 
�ndern diese sich, sollen die Observer benachrichtigt werden (update), so dass diese anschlie�end 
die aktuellen Wetterdaten abfragen und auswerten k�nnen.
Observer sollen sich sowohl registrieren als auch wieder deregistrieren k�nnen.