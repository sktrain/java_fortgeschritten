package sk.train.ma.abs;

import java.math.BigDecimal;
import java.time.LocalDate;

public class TestMitarbeiter {

	public static void main(String[] args) {
		
		//Mitarbeiter kann nicht mehr instantiiert werden
		//Mitarbeiter m =new Mitarbeiter("Stephan", "Karrer", LocalDate.of(1959, 8,14), LocalDate.now(), Geschlecht.M);
		
		Arbeiter a = new Arbeiter("Stephan", "Karrer", LocalDate.of(1959, 8,14), LocalDate.now(), Geschlecht.M,
				                  new BigDecimal("50"), new BigDecimal("100"));
				
		System.out.println(a);
		
		FixGehaltMitarbeiter f = new FixGehaltMitarbeiter("Erika", "Musterfrau", LocalDate.of(2000, 11, 15), LocalDate.of(2020,  1, 1),
                                                          Geschlecht.W, new BigDecimal("4000"));
		
		System.out.println(f);
		
		

	}

}
