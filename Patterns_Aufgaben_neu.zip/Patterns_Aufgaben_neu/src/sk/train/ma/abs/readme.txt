Schritt 1: Die vorhandene Mitarbeiterimplementierung soll mittels des Strategy-Patterns
umgestellt werden: Mitarbeiter haben ein Gehaltsmodell.

Schritt 2: Entsprechende Gehaltsmodelle k�nnen durch eine Factory-Methode geliefert werden
(Factory Method Pattern)
