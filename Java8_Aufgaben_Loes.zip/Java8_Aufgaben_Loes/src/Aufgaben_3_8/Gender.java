package Aufgaben_3_8;

public enum Gender
{
    MALE, FEMALE, UNKNOWN;
}