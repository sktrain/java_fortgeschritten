package appl;

public class CloseEvent extends MathEvent {

	private static final long serialVersionUID = 1L;

	public CloseEvent(Object source) {
		super(source);
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " []";
	}
}
