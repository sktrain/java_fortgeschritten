/* Mitarbeiter-L�sung erweitert um verschiedene Sortiervarianten:
 * Lambdas werden kurz eingef�hrt.
 */

package sk.train.ma.strategy;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;

public class MItarbeiterVerwaltungTest {

	public static void main(String[] args) {

		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();
		
		//System.out.println(Objects.isNull(mv));

		print(mv);
		
		printNaturalOrder(mv);
		
		printSortedByName(mv);

		printSortedByGebDatum(mv);

		printSortedByGebDatumAndGehalt(mv);

	}
	

	private static void print(MitarbeiterVerwaltung mv) {
		//Ausgabe sortiert nach dem Key, da TreeMaps die Values nicht geordnet speichern
		System.out.println(mv);   //vorausgesetzt entsprechende toString-Methode
		

	}

	private static void printNaturalOrder(MitarbeiterVerwaltung mv) {
		// Jetzt nach Geh�ltern sortiert (natural order)
		System.out.println("\n***********Hier nach Gehalt sortiert**************\n");
		mv.getMlist(Comparator.naturalOrder()).forEach(System.out::println);
	}

	private static void printSortedByName(MitarbeiterVerwaltung mv) {
		// jetzt nach Nachnamen sortiert
		System.out.println("\n***********Hier nach Nachnamen sortiert**************\n");
		mv.getMlist(new NachnamenComparator()).forEach(System.out::println);
	}

	private static void printSortedByGebDatum(MitarbeiterVerwaltung mv) {
		// jetzt mal nur per Lambda nach den Geburtsdaten und Ausgabe mit
		// foreach-Lambda-Version
		System.out.println("\n***********Hier nach Geburtsdatum sortiert**************\n");
		Comparator<Mitarbeiter> cgebdatum = (Mitarbeiter m1, Mitarbeiter m2) -> {
			return m1.getGebdatum().compareTo(m2.getGebdatum());
		};
		mv.getMlist(cgebdatum).forEach(System.out::println);
	}
	
	private static void printSortedByGebDatumAndGehalt(MitarbeiterVerwaltung mv) {
		// und jetzt mal zuerst nach den Geburtsdaten und dann nachsortiert anhand der Geh�lter
		System.out.println("\n******Hier nach Geburtsdatum und Gehalt sortiert************\n");
		Comparator<Mitarbeiter> cgebdatum = (Mitarbeiter m1, Mitarbeiter m2) -> {
			return m1.getGebdatum().compareTo(m2.getGebdatum());
		};
		Comparator<Mitarbeiter> cgehalt = (Mitarbeiter m1, Mitarbeiter m2) -> {
			return m1.getGmodell().getGehalt().compareTo(m2.getGmodell().getGehalt());
		};
		mv.getMlist(cgebdatum.thenComparing(cgehalt)).forEach(System.out::println);;
		
	}

}
