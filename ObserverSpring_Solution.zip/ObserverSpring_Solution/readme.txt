Umsetzung des Observer/Observable-Pattern:
 
Nutzung des Spring-Context.
Die �nderungen werden jetzt direkt den Observern mitgeteilt, statt dass diese selbst die 
�nderungen erfragen.
