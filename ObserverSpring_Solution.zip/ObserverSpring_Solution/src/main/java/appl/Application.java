package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) throws InterruptedException {
		try(final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class)){
			
			WeatherStation station = ctx.getBean(WeatherStation.class);
			
			WeatherData weatherData = new WeatherData(station);
			
			//Wetter�nderungen durchf�hren: sollte zu Benachrichtigung der Observer f�hren und die erzeugen entsprechende Ausgaben
				
			weatherData.setMeasurements(80, 65, 30.4f);	
			station.changeWeather(weatherData);
			
			Thread.sleep(5000); //5 Sekunden warten
			
			//todo mit weiteren Wetterdaten
			
			weatherData.setMeasurements(82, 70, 29.2f);
			station.changeWeather(weatherData);
			
			Thread.sleep(5000); //5 Sekunden warten
			
			weatherData.setMeasurements(78, 90, 29.2f);
			station.changeWeather(weatherData);
			
		}
	}
}
