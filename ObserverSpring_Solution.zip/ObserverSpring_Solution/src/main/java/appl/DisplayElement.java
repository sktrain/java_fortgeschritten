package appl;

public interface DisplayElement {
	public void display();
}
