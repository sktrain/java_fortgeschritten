package appl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	
	@Bean
	@Autowired
	public WeatherStation weatherstation(ConfigurableApplicationContext ctx) {
		return new WeatherStation(ctx);		
	}
	
	@Bean
	@Autowired
	public CurrentConditionsDisplay currentConditions(ConfigurableApplicationContext ctx) {
		return new CurrentConditionsDisplay(ctx);		
	}
	
	@Bean
	@Autowired
	public ForecastDisplay forecast(ConfigurableApplicationContext ctx) {
		return new ForecastDisplay(ctx);		
	}
	
	@Bean
	@Autowired
	public StatisticsDisplay statistics(ConfigurableApplicationContext ctx) {
		return new StatisticsDisplay(ctx);		
	}

}
