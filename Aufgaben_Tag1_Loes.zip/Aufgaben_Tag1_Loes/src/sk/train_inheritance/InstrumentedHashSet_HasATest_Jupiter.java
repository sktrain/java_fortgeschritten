package sk.train_inheritance;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class InstrumentedHashSet_HasATest_Jupiter {

	private InstrumentedHashSet_HasA<String> set;
	
	@BeforeEach
	void setUp() throws Exception {
		set = new InstrumentedHashSet_HasA<String>();
	}

	@Test
	void testAdd() {
		set.add("Hallo");
		assertEquals(1, set.getAddCount(), "Falsche Anzahl");
	}

	@Test
	void testAddAll() {
		set.addAll(Arrays.asList("Snap", "Crackle", "Pop"));
		assertEquals(3, set.getAddCount(),"Falsche Anzahl");
	}

}
