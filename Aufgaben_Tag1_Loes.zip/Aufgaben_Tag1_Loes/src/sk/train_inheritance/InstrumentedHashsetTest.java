package sk.train_inheritance;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

public class InstrumentedHashsetTest {
	
	private InstrumentedHashSet_HasA<String> set;

	@Before
	public void setUp() throws Exception {
		set = new InstrumentedHashSet_HasA<String>();
	}

	@Test
	public void testAdd() {
		set.add("Hallo");
		assertEquals("Falsche Anzahl", 1, set.getAddCount() );
	}

	@Test
	public void testAddAll() {
		set.addAll(Arrays.asList("Snap", "Crackle", "Pop"));
		assertEquals("Falsche Anzahl", 3, set.getAddCount());
	}

}
