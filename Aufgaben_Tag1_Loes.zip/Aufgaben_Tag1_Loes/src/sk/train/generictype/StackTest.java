package sk.train.generictype;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class StackTest {

	private Stack<Number> numberStack;
	
	@Before
	public void setUp() throws Exception {
		numberStack = new Stack<Number>();
	}

	@Ignore @Test
	public void testPush() {
		fail("Not yet implemented");
	}

	@Ignore @Test
	public void testPop() {
		fail("Not yet implemented");
	}

	@Ignore @Test
	public void testIsEmpty() {
		fail("Not yet implemented");
	}

	@Test
	public void testPushAll() {
		Iterable<Integer> integers = Arrays.asList(3, 1, 4, 1, 5, 9);
		numberStack.pushAll(integers);
		Collection<Number> numbers = new ArrayList<Number>();
		numberStack.popAll(numbers);
		assertArrayEquals("wrong order", new Number[] {9, 5, 1, 4, 1, 3}, numbers.toArray(new Number[6]));
	}

	@Test
	public void getCapacity() {
        assertEquals("wrong capacity", 16, numberStack.getCapacity());		
		for (int i = 1; i<20; ++i) {
			numberStack.push(i);
		}
		assertEquals("wrong capacity", 32, numberStack.getCapacity());	
	}
	
	@Test
	public void testStackIntUnaryOperator() {
		numberStack = new Stack<Number>(cap -> cap + 5);
		assertEquals("wrong capacity", 16, numberStack.getCapacity());
		for (int i = 1; i<20; ++i) {
			numberStack.push(i);
		}
		assertEquals("wrong capacity", 21, numberStack.getCapacity());
	}
	
	@Test(expected = IllegalStrategyException.class)
	public void testStackIntUnaryOperatorWithException() {
		numberStack = new Stack<>(cap -> cap);
	}
	
	@Test(expected = EmptyStackException.class)
	public void testEmptyStackWithException() {
		numberStack.pop();
	}

}
